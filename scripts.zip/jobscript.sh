#!/bin/bash
#SBATCH --job-name=tacotron2_250Test
#SBATCH --output=/scratch/s6028608/output.log
#SBATCH --error=/scratch/s6028608/error.log
#SBATCH --time 0-48:30:00
#SBATCH --gres=gpu:1

module --force purge
module --ignore_cache load Python/3.8.6-GCCcore-10.2.0
module --ignore_cache load CUDA/11.8.0
module --ignore_cache load cuDNN/8.7.0.84-CUDA-11.8.0

source /scratch/s6028608/venvs/first_env/bin/activate 

cd /scratch/s6028608/DeepLearningExamples/PyTorch/SpeechSynthesis/Tacotron2

mkdir -p output
python -m multiproc train.py -m Tacotron2 -o ./output/ -lr 1e-3 --epochs 250 -bs 48 --weight-decay 1e-6 --grad-clip-thresh 1.0 --cudnn-enabled --log-file nvlog.json --anneal-steps 500 1000 1500 --anneal-factor 0.1


