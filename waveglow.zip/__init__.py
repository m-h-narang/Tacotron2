from .entrypoints import nvidia_waveglow
